//
//  GuessTheFlagApp.swift
//  GuessTheFlag
//
//  Created by Victor Tene on 08.08.2024.
//

import SwiftUI

@main
struct GuessTheFlagApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
